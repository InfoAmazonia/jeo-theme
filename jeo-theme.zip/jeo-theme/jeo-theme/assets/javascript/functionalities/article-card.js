window.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll('article.category-audio, article.category-map, article.category-video')
})