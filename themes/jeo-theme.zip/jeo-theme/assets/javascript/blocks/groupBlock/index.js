wp.domReady( () => {

	wp.blocks.registerBlockStyle( 'core/group', [
		{
			name: 'home__block-sidebar',
			label: 'Gray column with primary color heading',
		}
	]);
} );