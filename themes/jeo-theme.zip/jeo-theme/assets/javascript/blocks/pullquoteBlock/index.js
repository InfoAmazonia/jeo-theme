wp.domReady( () => {

	wp.blocks.registerBlockStyle( 'core/pullquote', [
		{
			name: 'jeo',
			label: 'Big left quote',
		},
	]);
} );